#!/bin/bash

n1=1
n2=1
n3=1

if [ "$USER" = "root" ]; then
	user=$SUDO_USER
else
	user=$USER
fi

pasta_conficuracao=/home/$user/.Agendador
pasta_aplicacoes=/usr/share/Agendador

nome="d m a"
for i in $nome
do
	if ! [ -e "$pasta_conficuracao/test$i.conf" ]; then
		touch $pasta_conficuracao/test$i.conf
		chown $user:$user $pasta_conficuracao/test$i.conf
		chmod 664 $pasta_conficuracao/test$i.conf
	fi
	
	if ! [ -e "$pasta_conficuracao/agendamentos$i.conf" ]; then
		touch $pasta_conficuracao/agendamentos$i.conf
		chown $user:$user $pasta_conficuracao/agendamentos$i.conf
		chmod 664 $pasta_conficuracao/agendamentos$i.conf
	fi
	
	if ! [ -e "$pasta_conficuracao/removidos$i.conf" ]; then
		touch $pasta_conficuracao/removidos$i.conf
		chown $user:$user $pasta_conficuracao/removidos$i.conf
		chmod 664 $pasta_conficuracao/removidos$i.conf
	fi
	if ! [ -e "$pasta_conficuracao/descricao$i.conf" ]; then
		touch $pasta_conficuracao/descricao$i.conf
		chown $user:$user $pasta_conficuracao/descricao$i.conf
		chmod 664 $pasta_conficuracao/descricao$i.conf
	fi
done

if ! [ -e "$pasta_conficuracao/agenda.conf" ]; then
	touch $pasta_conficuracao/agenda.conf
	chown $user:$user $pasta_conficuracao/agenda.conf
	chmod 664 $pasta_conficuracao/agenda.conf
fi

nome="dia mes ano"
for i in $nome
do
	if ! [ -e "$pasta_conficuracao/agenda$i.conf" ]; then
		touch $pasta_conficuracao/agenda$i.conf
		chown $user:$user $pasta_conficuracao/agenda$i.conf
		chmod 664 $pasta_conficuracao/agenda$i.conf
	fi
done

tam1=$(wc -w $pasta_conficuracao/testd.conf| cut -d " " -f1)
tam2=$(wc -w $pasta_conficuracao/testm.conf| cut -d " " -f1)
tam3=$(wc -w $pasta_conficuracao/testa.conf| cut -d " " -f1)

if [ "$tam1" != "0" ]; then
	teste1=$(cat $pasta_conficuracao/testd.conf)
else
	teste1=0
fi
if [ "$tam2" != "0" ]; then
	teste2=$(cat $pasta_conficuracao/testm.conf)
else
	teste2=0
fi
if [ "$tam3" != "0" ]; then
	teste3=$(cat $pasta_conficuracao/testa.conf)
else
	teste3=0
fi

tempo_principal(){
	minutok=$(echo -e "$configuracao" | sed -n "$n,$n p" | cut -d ":" ${ka[0]})
	horak=$(echo -e "$configuracao" | sed -n "$n,$n p" | cut -d ":" ${ka[1]})
	tempok="${horak:1:2}:${minutok:0:2}"
	semanak=$(echo -e "$configuracao" | sed -n "$n,$n p" | cut -d ":" ${ka[2]})
	semanak=$(echo -e "$semanak" | cut -d "H" -f1)
	if [ "${#semanak}" != "0" ]; then
		semanak=$(echo "${semanak:1:$[${#semanak} - 4]}")
	fi
	mesek=$(echo -e "$configuracao" | sed -n "$n,$n p" | cut -d ":" ${ka[3]})
	mesek=$(echo -e "$mesek" | cut -d "D" -f1)
	if [ "${#mesek}" != "0" ]; then
		mesek=$(echo "${mesek:1:$[${#mesek} - 4]}")
	fi
	anok=$(echo -e "$configuracao" | sed -n "$n,$n p" | cut -d ":" ${ka[4]})
	anok=$(echo -e "$anok" | cut -d "M" -f1)
	if [ "${#anok}" != "0" ]; then
		anok=$(echo "${anok:1:$[${#anok} - 4]}")
	fi
}

ativador_principal(){
	ano=$(date +%Y)
	mes=$(date +%b)
	tempo=$(date +%R)
	for i in $ano2
		do
			case $ano in
				$i)
				for j in $mes2
				do
					case $mes in 
						$j)
						for k in $seman
						do
							case $dia1 in 
								$k)
								if [ "$tempo" = "$tempo2" ]; then 
									echo "$n" > $pasta_conficuracao/$agenda1
									echo "$n_1" > $pasta_conficuracao/$agenda
									if [ "$n" != "$teste_1" ]; then
										teste_1="$n"
										echo "$teste_1" > $pasta_conficuracao/$teste
										roxterm -e "bash -c $pasta_aplicacoes/mostrador.sh" &
										sleep 1
									fi
								fi
								;;
							esac
						done
						;;
					esac
				done
				;;
			esac
		done
}

while true
do	
	diaconfiguracao="$(cat $pasta_conficuracao/agendamentosd.conf)"
	mesconfiguracao="$(cat $pasta_conficuracao/agendamentosm.conf)"
	anoconfiguracao="$(cat $pasta_conficuracao/agendamentosa.conf)"
	test1="${#diaconfiguracao}"
	test2="${#mesconfiguracao}"
	test3="${#anoconfiguracao}"
	if [ "$test1" != "0" ]; then
		cont=$(echo -e "$diaconfiguracao" | tail -n 1 | cut -d "-" -f1)
		cont=$(echo "${cont:0:$[${#cont} - 1]}")
	else
		cont=0
	fi
	if [ "$test2" != "0" ]; then
		cont1=$(echo -e "$mesconfiguracao" | tail -n 1 | cut -d "-" -f1)
		cont1=$(echo "${cont1:0:$[${#cont1} - 1]}")
	else
		cont1=0
	fi
	if [ "$test3" != "0" ]; then
		cont2=$(echo -e "$anoconfiguracao" | tail -n 1 | cut -d "-" -f1)
		cont2=$(echo "${cont2:0:$[${#cont2} - 1]}")
	else
		cont2=0
	fi
	sem=$(date +%a)
	dia_d=$(date +%d) 
	removidod=$(cat $pasta_conficuracao/removidosd.conf)
	for i in $removidod
	do
		if [ "$i" = "$teste1" ]; then
			echo "0" > $pasta_conficuracao/testd.conf
			teste1=0
			echo "0" > $pasta_conficuracao/removidosd.conf
		fi
	done
	removidom=$(cat $pasta_conficuracao/removidosm.conf)
	for i in $removidom
	do
		if [ "$i" = "$teste2" ]; then
			echo "0" > $pasta_conficuracao/testm.conf
			teste2=0
			echo "0" > $pasta_conficuracao/removidosm.conf
		fi
	done
	removidoa=$(cat $pasta_conficuracao/removidosa.conf)
	for i in $removidoa
	do
		if [ "$i" = "$teste3" ]; then
			echo "0" > $pasta_conficuracao/testa.conf
			teste3=0
			echo "0" > $pasta_conficuracao/removidosa.conf
		fi
	done
	if [ "$tempo" = "00:00" -o "$test1" = "0" ]; then
		echo "0" > $pasta_conficuracao/testd.conf
		teste1=0
	fi
	if [ "$tempo" = "00:00" -o "$test2" = "0" ]; then
		echo "0" > $pasta_conficuracao/testm.conf
		teste2=0
	fi
	if [ "$tempo" = "00:00" -o "$test3" = "0" ]; then
		echo "0" > $pasta_conficuracao/testa.conf
		teste3=0
	fi
	if [ "$cont" != "0" ]; then
		if [ "$n1" = "$cont" ]; then
			n1=1
		else
			n1=$[n1 + 1]
		fi
		configuracao=$diaconfiguracao
		ka=("-f5" "-f4" "-f3" "-f2" "-f1")
		n=$n1
		tempo_principal
		ano2=$ano
		mes2=$mes
		seman=$semanak
		dia1=$sem
		n_1=1
		tempo2=$tempok
		agenda1="agendadia.conf"
		agenda="agenda.conf"
		teste="testd.conf"
		teste_1=$teste1
		ativador_principal
		teste1=$teste_1
	fi
	if [ "$cont1" != "0" ]; then
		if [ "$n2" = "$cont1" ]; then
			n2=1
		else
			n2=$[n2 + 1]
		fi
		configuracao=$mesconfiguracao
		ka=("-f6" "-f5" "-f4" "-f3" "-f2")
		n=$n2
		tempo_principal
		ano2=$ano
		mes2=$mesek
		seman=$semanak
		dia1=$dia_d
		n_1=2
		tempo2=$tempok
		agenda1="agendames.conf"
		agenda="agenda.conf"
		teste="testm.conf"
		teste_1=$teste2
		ativador_principal
		teste2=$teste_1
	fi
	if [ "$cont2" != "0" ]; then
		if [ "$n3" = "$cont2" ]; then
			n3=1
		else
			n3=$[n3 + 1]
		fi
		configuracao=$anoconfiguracao
		ka=("-f7" "-f6" "-f5" "-f4" "-f3")
		n=$n3
		tempo_principal
		ano2=$anok
		mes2=$mesek
		seman=$semanak
		dia1=$dia_d
		n_1=3
		tempo2=$tempok
		agenda1="agendaano.conf"
		agenda="agenda.conf"
		teste="testa.conf"
		teste_1=$teste3
		ativador_principal
		teste3=$teste_1
	fi
	sleep 3
done

exit 0
