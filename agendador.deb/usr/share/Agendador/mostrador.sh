#!/bin/bash

echo "0" > /home/marxfcmonte/.Agendador/confirmacao.conf 
anoconfiguracao=$(cat /home/marxfcmonte/.Agendador/agendamentosa.conf)
mesconfiguracao=$(cat /home/marxfcmonte/.Agendador/agendamentosm.conf)
diaconfiguracao=$(cat /home/marxfcmonte/.Agendador/agendamentosd.conf)
agenda=
case $agenda in 
	1)
	n1=$(cat /home/marxfcmonte/.Agendador/agendadia.conf)
	texto=$(echo -e "$diaconfiguracao" | sed -n "$n1,$n1 p" | cut -d ":" -f2 | cut -d "D" -f1)
	texto=$(echo "${texto:0:$[${#texto} - 1]}")
	;;
	2)
	n2=$(cat /home/marxfcmonte/.Agendador/agendames.conf)
	texto=$(echo -e "$mesconfiguracao" | sed -n "$n2,$n2 p" | cut -d ":" -f2 | cut -d "M" -f1)
	texto=$(echo "${texto:0:$[${#texto} - 1]}")
	;;
	3)
	n3=$(cat /home/marxfcmonte/.Agendador/agendaano.conf)
	texto=$(echo -e "$anoconfiguracao" | sed -n "$n3,$n3 p" | cut -d ":" -f2 | cut -d "A" -f1)
	texto=$(echo "${texto:0:$[${#texto} - 1]}")
	;;
esac
cont="$[${#texto} + 4]"
dialog --title "$texto" --msgbox "$texto" 6 43 
clear
echo "1" > /home/marxfcmonte/.Agendador/confirmacao.conf 

exit 0

