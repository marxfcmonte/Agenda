#!/bin/bash

if [ "$USER" = "root" ]; then
	user=$SUDO_USER
else
	user=$USER
fi

pasta_conficuracao=/home/$user/.Agendador
descricaod=$(cat $pasta_conficuracao/descricaod.conf)
descricaom=$(cat $pasta_conficuracao/descricaom.conf)
descricaoa=$(cat $pasta_conficuracao/descricaoa.conf)

agenda=$(cat $pasta_conficuracao/agenda.conf)
case $agenda in 
	1)
	n1=$(cat $pasta_conficuracao/agendadia.conf)
	texto=$(echo -e "$descricaod" | sed -n "$n1,$n1 p")
	texto1="TAREFA AGENDADA - SEMANAL"
	;;
	2)
	n2=$(cat $pasta_conficuracao/agendames.conf)
	texto=$(echo -e "$descricaom" | sed -n "$n2,$n2 p")
	texto1="TAREFA AGENDADA - MENSAL"
	;;
	3)
	n3=$(cat $pasta_conficuracao/agendaano.conf)
	texto=$(echo -e "$descricaoa" | sed -n "$n3,$n3 p")
	texto1="TAREFA AGENDADA - ANUAL"
	;;
esac
cont2="$[${#texto} + 4]"
cont1="$[${#texto1} + 4]"

if [ $cont1 -gt $cont2 ]; then
	cont=$cont1
else
	cont=$cont2
fi

dialog --colors --title "\Zr\Z1  $texto1                          
              \Zn" --msgbox "$texto" 6 $cont 
clear

exit 0
