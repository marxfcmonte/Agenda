#!/bin/bash

n1=1
n2=1
n3=1
echo "0" > /home/marxfcmonte/.Agendador/finalizar.conf

while true
do
	
	diaconfiguracao=$(cat /home/marxfcmonte/.Agendador/agendamentosd.conf)
	mesconfiguracao=$(cat /home/marxfcmonte/.Agendador/agendamentosm.conf)
	anoconfiguracao=$(cat /home/marxfcmonte/.Agendador/agendamentosa.conf)
	test="${#diaconfiguracao}"
	test1="${#mesconfiguracao}"
	test2="${#anoconfiguracao}"
	if [ "$test" != "0" ]; then
		cont=$(echo -e "$diaconfiguracao" | tail -n 1 | cut -d "-" -f1)
		cont=$(echo "${cont:0:$[${#cont} - 1]}")
	else
		cont=0
	fi
	if [ "$test1" != "0" ]; then
		cont1=$(echo -e "$mesconfiguracao" | tail -n 1 | cut -d "-" -f1)
		cont1=$(echo "${cont1:0:$[${#cont1} - 1]}")
	else
		cont1=0
	fi
	if [ "$test2" != "0" ]; then
		cont2=$(echo -e "$anoconfiguracao" | tail -n 1 | cut -d "-" -f1)
		cont2=$(echo "${cont2:0:$[${#cont2} - 1]}")
	else
		con2=0
	fi
	if [ "$n1" = "$cont" ]; then
		n1=1
	else
		n1=$[n1 + 1]
	fi
	if [ "$n2" = "$cont1" ]; then
		n2=1
	else
		n2=$[n2 + 1]
	fi
	if [ "$n3" = "$cont2" ]; then
		n3=1
	else
		n3=$[n3 + 1]
	fi
	minutod=$(echo -e "$diaconfiguracao" | sed -n "$n1,$n1 p" | cut -d ":" -f5)
	horad=$(echo -e "$diaconfiguracao" | sed -n "$n1,$n1 p" | cut -d ":" -f4)
	tempod="${horad:1:2}:${minutod:0:2}"
	semanad=$(echo -e "$diaconfiguracao" | sed -n "$n1,$n1 p" | cut -d ":" -f3)
	semanad=$(echo -e "$semanad" | cut -d "H" -f1)
	semanad=$(echo "${semanad:1:$[${#semanad} - 1]}")
	minutom=$(echo -e "$mesconfiguracao" | sed -n "$n2,$n2 p" | cut -d ":" -f6)
	horam=$(echo -e "$mesconfiguracao" | sed -n "$n2,$n2 p" | cut -d ":" -f5)
	tempom="${horam:1:2}:${minutom:0:2}"
	semanam=$(echo -e "$mesconfiguracao" | sed -n "$n2,$n2 p" | cut -d ":" -f4)
	semanam=$(echo -e "$semanam" | cut -d "H" -f1)
	semanam=$(echo "${semanam:1:$[${#semanam} - 2]}")
	meses=$(echo -e "$mesconfiguracao" | sed -n "$n2,$n2 p" | cut -d ":" -f3)
	meses=$(echo -e "$meses" | cut -d "D" -f1)
	meses=$(echo "${meses:1:$[${#meses} - 1]}")
	minutoa=$(echo -e "$anoconfiguracao" | sed -n "$n3,$n3 p" | cut -d ":" -f7)
	horaa=$(echo -e "$anoconfiguracao" | sed -n "$n3,$n3 p" | cut -d ":" -f6)
	tempoa="${horaa:1:2}:${minutoa:0:2}"
	semanaa=$(echo -e "$anoconfiguracao" | sed -n "$n3,$n3 p" | cut -d ":" -f5)
	semanaa=$(echo -e "$semanaa" | cut -d "H" -f1)
	semanaa=$(echo "${semanaa:1:$[${#semanaa} - 2]}")
	mesesa=$(echo -e "$anoconfiguracao" | sed -n "$n3,$n3 p" | cut -d ":" -f4)
	mesesa=$(echo -e "$mesesa" | cut -d "D" -f1)
	mesesa=$(echo "${mesesa:1:$[${#mesesa} - 1]}")
	anos=$(echo -e "$anoconfiguracao" | sed -n "$n3,$n3 p" | cut -d ":" -f3)
	anos=$(echo -e "$anos" | cut -d "M" -f1)
	anos=$(echo "${anos:1:$[${#anos} - 1]}")
	ano=$(date +%Y)
	mes=$(date +%m)
	sem=$(date +%w) 
	tempo="$(date +%H):$(date +%M)"
	if [ "$cont" != "0" ]; then
		for i in $semanad
		do
			case $sem in 
				$i)
				if [ "$tempo" = "$tempod" ]; then 
					echo "$n1" > /home/marxfcmonte/.Agendador/agendadia.conf
					echo "1" > /home/marxfcmonte/.Agendador/agenda.conf
					sleep 1
					roxterm -e "bash -c /usr/share/Agendador/mostrador.sh"
					while true
					do
						confirmacao=$(cat /home/marxfcmonte/.Agendador/confirmacao.conf)
						if [ "$confirmacao" = "1" ]; then
							sleep 70
							break
						fi
					done
					sleep 2
				fi
				;;
			esac
		done
	fi
	if [ "$cont1" != "0" ]; then
		for i in $meses
		do
			case $mes in 
				$i)
				for j in $semanam
				do
					case $sem in 
						$j)
						if [ "$tempo" = "$tempom" ]; then 
							echo "$n2" > /home/marxfcmonte/.Agendador/agendames.conf
							echo "2" > /home/marxfcmonte/.Agendador/agenda.conf
							sleep 1
							roxterm -e "bash -c $pastaj/mostrador.sh"
							while true
							do
								confirmacao=$(cat /home/marxfcmonte/.Agendador/confirmacao.conf)
								if [ "$confirmacao" -eq 0 ]; then
									sleep 70
									break
								fi
							done
							sleep 2
						fi
						;;
					esac
				done
				;;
			esac
		done
	fi
	if [ "$cont2" != "0" ]; then
		for i in $anos
		do
			case $ano in
				$i)
				for j in $mesesa
				do
					case $mes in 
						$j)
						for k in $semanaa
						do
							case $sem in 
								$k)
								if [ "$tempo" = "$tempoa" ]; then 
									echo "$n3" > /home/marxfcmonte/.Agendador/agendaano.conf
									echo "3" > /home/marxfcmonte/.Agendador/agenda.conf
									sleep 1
									roxterm -e "bash -c /usr/share/Agendador/mostrador.sh"
									while true
									do
										confirmacao=$(cat /home/marxfcmonte/.Agendador/confirmacao.conf)
										if [ "$confirmacao" -eq 1 ]; then
											sleep 70
											break
										fi
									done
									sleep 2
								fi
								;;
							esac
						done
						;;
					esac
				done
				;;
			esac
		done
	fi
	finalizar=$(cat /home/marxfcmonte/.Agendador/finalizar.conf)
	if [ "$finalizar" = "1" ]; then
		break
	fi
	sleep 1
done


