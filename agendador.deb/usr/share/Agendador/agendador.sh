#!/bin/bash

cadastro_principal(){ 
	descricao=$(dialog --title "Descrição" --inputbox "Nome do agendamento: " 0 0		--stdout) 
	clear
	if [ "$descricao" ]; then 
		while true
		do	
			tempoh=$(dialog --title "Tempo da hora" --inputbox "Informe a hora [00 a 23]: " 8 29			--stdout) 
			clear
			if [ "$tempoh" ]; then
				for j in $(echo "$hora")
				do
					echo "$j"
					if [ "$tempoh" = "$j" ]; then
						teste=0
						break
					else
						teste=1
					fi
				done
				if [ "$teste" -eq 1 ]; then
					clear
					dialog --title "ERRO" --infobox "HORA INVÁLIDA!" 3 18
					sleep 1
					clear
				else
					break
				fi
			else
				cancelar
			fi
		done
		while true
		do	
			tempom=$(dialog --title "Tempo do minuto" --inputbox "Informe a minuto [00 a 59]: " 8 32			--stdout)
			clear
			if [ "$tempom" ]; then
				for j in $(echo "$minuto")
				do
					echo "$j"
					if [ "$tempom" = "$j" ]; then
						teste=0
						break
					else
						teste=1
					fi
				done
				if [ "$teste" -eq 1 ]; then
					clear
					dialog --title "ERRO" --infobox "MINUTO INVÁLIDO!" 3 20
					sleep 1
					clear
				else
					break
				fi 
			else
				cancelar
			fi
		done
	else
		cancelar
	fi
}

semana_principal(){
	opcao2=$(dialog --no-cancel --title "MENU - DIAS DA SEMANA" --checklist "Qual dos dias da semana serão habilitados?" 14 47 7 "1" "Segunda-feira" ${estado[0]} "2" "Terça-feira" ${estado[1]} "3" "Quarta-feira" ${estado[2]} "4" "Quinta-feira" ${estado[3]} "5" "Sexta-feira" ${estado[4]} "6" "Sábado" ${estado[5]} "7" "Domingo" ${estado[6]} --stdout)
}

mes_principal(){
	opcao3=$(dialog --no-cancel --title "MENU - MESES D0 ANO" --checklist "Qual dos meses serão habilitados?" 19 38 12 "01" "Janeiro" ${estado1[0]} "02" "Fevereiro" ${estado1[1]} "03" "Março" ${estado1[2]} "04" "Abril" ${estado1[3]} "05" "Maio" ${estado1[4]} "06" "Junho" ${estado1[5]} "07" "Julho" ${estado1[6]} "08" "Agosto" ${estado1[7]} "09" "Setembro" ${estado1[8]} "10" "Outubro" ${estado1[9]} "11" "Novembro" ${estado1[10]} "12" "Dezembro" ${estado1[11]} --stdout)
}

ano_principal(){
	opcao4=$(dialog --no-cancel --title "MENU - ANOS DE 2025 A 2036" --checklist "Qual dos anos serão habilitados?" 19 37 12 "2025" "Ano 2025" ${estado2[0]} "2026" "Ano 2026" ${estado2[1]} "2027" "Ano 2027" ${estado2[2]} "2028" "Ano 2028" ${estado2[3]} "2029" "Ano 2029" ${estado2[4]} "2030" "Ano 2030" ${estado2[5]} "2031" "Ano 2031" ${estado2[6]} "2032" "Ano 2032" ${estado2[7]} "2033" "Ano 2033" ${estado2[8]} "2034" "Ano 2034" ${estado2[9]} "2035" "Ano 2035" ${estado2[10]} "2036" "Ano 2036" ${estado2[11]} --stdout)
}

agendamento_principal(){
	num1=$[$(cat /home/marxfcmonte/.Agendador/agendamentosd.conf | tail -n 1 | cut -d " " -f1) + 1 ]
	if ! [ $num1 ]; then
		num1=0
	fi
	num2=$[$(cat /home/marxfcmonte/.Agendador/agendamentosm.conf | tail -n 1 | cut -d " " -f1) + 1 ]
	if ! [ $num2 ]; then
		num2=0
	fi
	num3=$[$(cat /home/marxfcmonte/.Agendador/agendamentosa.conf | tail -n 1 | cut -d " " -f1) + 1 ]
	if ! [ $num3 ]; then
		num3=0
	fi
	dia=$(date +%u)
	case $dia in
		1) estado=("ON" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		2) estado=("OFF" "ON" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		3) estado=("OFF" "OFF" "ON" "OFF" "OFF" "OFF" "OFF") ;;
		4) estado=("OFF" "OFF" "OFF" "ON" "OFF" "OFF" "OFF") ;;
		5) estado=("OFF" "OFF" "OFF" "OFF" "ON" "OFF" "OFF") ;;
		6) estado=("OFF" "OFF" "OFF" "OFF" "OFF" "ON" "OFF") ;;
		7) estado=("OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "ON") ;;
	esac
	mes=$(date +%m)
	case $mes in
		"01") estado1=("ON" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		"02") estado1=("OFF" "ON" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		"03") estado1=("OFF" "OFF" "ON" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		"04") estado1=("OFF" "OFF" "OFF" "ON" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		"05") estado1=("OFF" "OFF" "OFF" "OFF" "ON" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		"06") estado1=("OFF" "OFF" "OFF" "OFF" "OFF" "ON" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		"07") estado1=("OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "ON" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		"08") estado1=("OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "ON" "OFF" "OFF" "OFF" "OFF") ;;
		"09") estado1=("OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "ON" "OFF" "OFF" "OFF") ;;
		"10") estado1=("OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "ON" "OFF" "OFF") ;;
		"11") estado1=("OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "ON" "OFF") ;;
		"12") estado1=("OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "ON") ;;
	esac
	ano=$(date +%Y)
	case $ano in
		"2025") estado2=("ON" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		"2026") estado2=("OFF" "ON" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		"2027") estado2=("OFF" "OFF" "ON" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		"2028") estado2=("OFF" "OFF" "OFF" "ON" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		"2029") estado2=("OFF" "OFF" "OFF" "OFF" "ON" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		"2030") estado2=("OFF" "OFF" "OFF" "OFF" "OFF" "ON" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		"2031") estado2=("OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "ON" "OFF" "OFF" "OFF" "OFF" "OFF") ;;
		"2032") estado2=("OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "ON" "OFF" "OFF" "OFF" "OFF") ;;
		"2033") estado2=("OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "ON" "OFF" "OFF" "OFF") ;;
		"2034") estado2=("OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "ON" "OFF" "OFF") ;;
		"2035") estado2=("OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "ON" "OFF") ;;
		"2036") estado2=("OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "OFF" "ON") ;;
	esac
	hora="00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23"
	minuto="00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 26 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59"
	opcao1=$(dialog --title "MENU - TIPOS DE AGENDAMEBTOS" --menu "Qual tipo de agendamento que deseja?" 12 40 5 "1" "Agendamentos semanais" "2" "Agendamentos mensais" "3" "Agendamentos anuais" "4" "Menu principal" "5" "Sair" --stdout)
	case $opcao1 in
		1) 
		cadastro_principal
		semana_principal
		teste=0
		k=""
		for i in $opcao2
		do	
			if [ teste -eq 0]; then
				k=$i
				semana="$k"
				teste=1
			else
				semana="$k$i "
				k="$k$i "
			fi
		done
		semana=${semana:0:$[${#semana} - 1]}
		sed '/^$/d' /home/marxfcmonte/.Agendador/agendamentosd.conf > /home/marxfcmonte/.Agendador/temp.conf && mv /home/marxfcmonte/.Agendador/temp.conf /home/marxfcmonte/.Agendador/agendamentosd.conf
		echo "$num1 - Descrição: $descricao Dias da Semana: $semana Horário: $tempoh:$tempom" >> /home/marxfcmonte/.Agendador/agendamentosd.conf
		clear
		tamanho="$(cat /home/marxfcmonte/.Agendador/agendamentosd.conf | tail -n 1)"
		tamanho=${#tamanho}
		tamanho=$[tamanho / 5]
		dialog --nocancel --title "AGENDAMENTO" --pause "$(cat /home/marxfcmonte/.Agendador/agendamentosd.conf | tail -n 1)" $tamanho 70 20
		clear
		opcao1=$(dialog --title "MENU" --menu "Qual opção vai escolher?" 10 30 3 "1" "Menu de agendamentos" "2" "Menu principal" "3" "Sair" --stdout)
		clear
		num=$(cat /home/marxfcmonte/.Agendador/finalizar.conf)
		if [ "$num" = "1" ]; then
			bash -c "/usr/share/Agendador/temporalizador.sh" &
			sleep 1
		fi
		case $opcao1 in
			1)
			agendamento_principal
			;;
			2)
			menu_principal
			;;
			3)
			sair
			;;
			*)
			cancelar
			;;
		esac
		;;
		2)
		cadastro_principal
		semana_principal
		mes_principal
		teste=0
		k=""
		for i in $opcao2
		do	
			if [ teste -eq 0]; then
				k=$i
				semana="$k"
				teste=1
			else
				semana="$k$i "
				k="$k$i "
			fi
		done
		teste=0
		k=""
		for i in $opcao3
		do	
			if [ teste -eq 0]; then
				k=$i
				meses="$k"
				teste=1
			else
				meses="$k$i "
				k="$k$i "
			fi
		done
		semana=${semana:0:$[${#semana} - 1]}
		meses=${meses:0:$[${#meses} - 1]}
		sed '/^$/d' /home/marxfcmonte/.Agendador/agendamentosm.conf > /home/marxfcmonte/.Agendador/temp.conf && mv /home/marxfcmonte/.Agendador/temp.conf /home/marxfcmonte/.Agendador/agendamentosm.conf
		echo "$num2 - Descrição: $descricao Meses do ano: $meses Dias da Semana: $semana Horário: $tempoh:$tempom" >> /home/marxfcmonte/.Agendador/agendamentosm.conf
		clear
		tamanho="$(cat /home/marxfcmonte/.Agendador/agendamentosm.conf | tail -n 1)"
		tamanho=${#tamanho}
		tamanho=$[tamanho / 7]
		dialog --nocancel --title "AGENDAMENTO" --pause "$(cat /home/marxfcmonte/.Agendador/agendamentosm.conf | tail -n 1) " $tamanho 70 20
		clear
		opcao1=$(dialog --title "MENU" --menu "Qual opção vai escolher?" 10 28 3 "1" "Menu de agendamentos" "2" "Menu principal" "3" "Sair" --stdout)
		clear
		num=$(cat /home/marxfcmonte/.Agendador/finalizar.conf)
		if [ "$num" = "1" ]; then
			bash -c "/usr/share/Agendador/temporalizador.sh" &
			sleep 1
		fi
		case $opcao1 in
			1)
			agendamento_principal
			;;
			2)
			menu_principal
			;;
			3)
			sair
			;;
			*)
			cancelar
			;;
		esac
		;;
		3) 
		cadastro_principal
		semana_principal
		mes_principal
		ano_principal
		teste=0
		k=""
		for i in $opcao2
		do	
			if [ teste -eq 0]; then
				k=$i
				semana="$k"
				teste=1
			else
				semana="$k$i "
				k="$k$i "
			fi
		done
		teste=0
		k=""
		for i in $opcao3
		do	
			if [ teste -eq 0]; then
				k=$i
				meses="$k"
				teste=1
			else
				meses="$k$i "
				k="$k$i "
			fi
		done
		teste=0
		k=""
		for i in $opcao4
		do	
			if [ teste -eq 0]; then
				k=$i
				anos="$k"
				teste=1
			else
				anos="$k$i "
				k="$k$i "
			fi
		done
		semana=${semana:0:$[${#semana} - 1]}
		meses=${meses:0:$[${#meses} - 1]}
		anos=${anos:0:$[${#anos} - 1]}
		sed '/^$/d' /home/marxfcmonte/.Agendador/agendamentosa.conf > /home/marxfcmonte/.Agendador/temp.conf && mv /home/marxfcmonte/.Agendador/temp.conf /home/marxfcmonte/.Agendador/agendamentosa.conf
		echo "$num3 - Descrição: $descricao Anos: $anos Meses do ano: $meses Dias da Semana: $semana Horário: $tempoh:$tempom" >> /home/marxfcmonte/.Agendador/agendamentosa.conf
		clear
		dialog --nocancel --no-collapse --title "LISTA DE AGENDAMENTOS ANUAIS" 		--textbox "/home/marxfcmonte/.Agendador/agendamentosa.conf | tail -n 1" 0 0 
		tamanho="$(cat /home/marxfcmonte/.Agendador/agendamentosa.conf | tail -n 1)"
		tamanho=${#tamanho}
		tamanho=$[tamanho / 7]
		dialog --nocancel --title "AGENDAMENTO" --pause "$(cat /home/marxfcmonte/.Agendador/agendamentosa.conf | tail -n 1) " $tamanho 70 20
		clear
		opcao1=$(dialog --title "MENU" --menu "Qual opção vai escolher?" 10 28 3 "1" "Menu de agendamentos" "2" "Menu principal" "3" "Sair" --stdout)
		clear
		num=$(cat /home/marxfcmonte/.Agendador/finalizar.conf)
		if [ "$num" = "1" ]; then
			bash -c "/usr/share/Agendador/temporalizador.sh" &
			sleep 1
		fi
		case $opcao1 in
			1)
			agendamento_principal
			;;
			2)
			menu_principal
			;;
			3)
			sair
			;;
			*)
			cancelar
			;;
		esac
		;;
		4)
		menu_principal
		;;
		5) 
		sair
		;;
		*)
		cancelar
		;;
	esac
}

remover_principal(){
	num=$(cat /home/marxfcmonte/.Agendador/agendamentosd.conf | tail -n 1 | cut -d " " -f1)
	if ! [ $num ]; then
		num=0
	fi
	num1=$(cat /home/marxfcmonte/.Agendador/agendamentosm.conf | tail -n 1 | cut -d " " -f1)
	if ! [ $num1 ]; then
		num1=0
	fi
	num2=$(cat /home/marxfcmonte/.Agendador/agendamentosa.conf | tail -n 1 | cut -d " " -f1)
	if ! [ $num2 ]; then
		num2=0
	fi
	opcao1=$(dialog --title "MENU - REMOÇÃO DE AGENDAMENTOS" --menu "Qual tipo de agendamento que deseja remover?" 13 48 5 "1" "Remover agendamentos semanais" "2" "Remover agendamentos mensais" "3" "Remover agendamentos anuais" "4" "Menu principal" "5" "Sair" --stdout)
	clear
	case $opcao1 in
		1)
		if [ "$num" != "0" ]; then 
			res=$(dialog --title "AGENDAMENTOS SEMANAIS" --keep-window --begin 0 0 --msgbox "$(cat /home/marxfcmonte/.Agendador/agendamentosd.conf)" 0 0 --and-widget --keep-window --begin 13 48 --inputbox "Informe o número do\nagendamento para remover?\n[Use um espaço entre\nos números informados.]" 0 0 --stdout) 
			res=$(echo "$res" | grep -o '[0-9]' | sort -n | tr '\n' ' ')
			if [ "$res" ]; then 
				for i in $res
				do
					awk -F "$i - " '{print $1}' /home/marxfcmonte/.Agendador/agendamentosd.conf > /home/marxfcmonte/.Agendador/temp.conf
					mv /home/marxfcmonte/.Agendador/temp.conf /home/marxfcmonte/.Agendador/agendamentosd.conf
				done
			fi
			sed '/^$/d' /home/marxfcmonte/.Agendador/agendamentosd.conf> /home/marxfcmonte/.Agendador/temp.conf && mv /home/marxfcmonte/.Agendador/temp.conf /home/marxfcmonte/.Agendador/agendamentosd.conf
			k=1
			num=$(cat /home/marxfcmonte/.Agendador/agendamentosd.conf | cut -d " " -f1)
			if ! [ $num ]; then
				num=0
			fi
			for i in $num
			do
				sed "s/$i -/$k -/g" /home/marxfcmonte/.Agendador/agendamentosd.conf > /home/marxfcmonte/.Agendador/temp.conf
				mv /home/marxfcmonte/.Agendador/temp.conf /home/marxfcmonte/.Agendador/agendamentosd.conf
				k=$[k + 1]
			done
		else
			dialog --nocancel --title "SEM AGENDAMENTOS SEMANAIS" --msgbox "Sem Compromissos agendados." 5 31
		fi
		clear
		opcao1=$(dialog --title "MENU" --menu "Qual opção vai escolher?" 10 41 3 "1" "Menu de remoção de agendamentos" "2" "Menu principal" "3" "Sair" --stdout)
		clear
		case $opcao1 in
			1)
			remover_principal
			;;
			2)
			menu_principal
			;;
			3)
			sair
			;;
			*)
			cancelar
			;;
		esac
		;;
		2)
		if [ "$num1" != "0" ]; then 
			res=$(dialog --title "AGENDAMENTOS MENSAIS" --keep-window --begin 0 0 --msgbox "$(cat /home/marxfcmonte/.Agendador/agendamentosm.conf)" 0 0 --and-widget --keep-window --begin 13 48 --inputbox "Informe o número do\nagendamento para remover?\n[Use um espaço entre\nos números informados.]" 0 0 --stdout) 
			res=$(echo "$res" | grep -o '[0-9]' | sort -n | tr '\n' ' ')
			if [ "$res" ]; then 
				for i in $res
				do
					awk -F "$i - " '{print $1}' /home/marxfcmonte/.Agendador/agendamentosm.conf > /home/marxfcmonte/.Agendador/temp.conf
					mv /home/marxfcmonte/.Agendador/temp.conf /home/marxfcmonte/.Agendador/agendamentosm.conf
				done
			fi
			sed '/^$/d' /home/marxfcmonte/.Agendador/agendamentosm.conf> /home/marxfcmonte/.Agendador/temp.conf && mv /home/marxfcmonte/.Agendador/temp.conf /home/marxfcmonte/.Agendador/agendamentosm.conf
			k=1
			num1=$(cat /home/marxfcmonte/.Agendador/agendamentosm.conf | cut -d " " -f1)
			if ! [ $num1 ]; then
				num1=0
			fi
			for i in $num1
			do
				sed "s/$i -/$k -/g" /home/marxfcmonte/.Agendador/agendamentosm.conf > /home/marxfcmonte/.Agendador/temp.conf
				mv /home/marxfcmonte/.Agendador/temp.conf /home/marxfcmonte/.Agendador/agendamentosm.conf
				k=$[k + 1]
			done
		else
			dialog --nocancel --title "SEM AGENDAMENTOS MENSAIS" --msgbox "Sem Compromissos agendados." 5 31
		fi
		clear
		opcao1=$(dialog --title "MENU" --menu "Qual opção vai escolher?" 10 41 3 "1" "Menu de remoção de agendamentos" "2" "Menu principal" "3" "Sair" --stdout)
		clear
		case $opcao1 in
			1)
			remover_principal
			;;
			2)
			menu_principal
			;;
			3)
			sair
			;;
			*)
			cancelar
			;;
		esac
		;;
		3)
		if [ "$num2" != "0" ]; then 
			res=$(dialog --title "AGENDAMENTOS ANUAIS" --keep-window --begin 0 0 --msgbox "$(cat /home/marxfcmonte/.Agendador/agendamentosa.conf)" 0 0 --and-widget --keep-window --begin 13 48 --inputbox "Informe o número do\nagendamento para remover?\n[Use um espaço entre\nos números informados.]" 0 0 --stdout) 
			res=$(echo "$res" | grep -o '[0-9]' | sort -n | tr '\n' ' ')
			if [ "$res" ]; then 
				for i in $res
				do
					awk -F "$i - " '{print $1}' /home/marxfcmonte/.Agendador/agendamentosa.conf > /home/marxfcmonte/.Agendador/temp.conf
					mv /home/marxfcmonte/.Agendador/temp.conf /home/marxfcmonte/.Agendador/agendamentosa.conf
				done
			fi
			sed '/^$/d' /home/marxfcmonte/.Agendador/agendamentosa.conf> /home/marxfcmonte/.Agendador/temp.conf && mv /home/marxfcmonte/.Agendador/temp.conf /home/marxfcmonte/.Agendador/agendamentosa.conf
			num2=$(cat /home/marxfcmonte/.Agendador/agendamentosa.conf | cut -d " " -f1)
			if ! [ $num2 ]; then
				num2=0
			fi
			k=1
			for i in $num2
			do
				sed "s/$i -/$k -/g" /home/marxfcmonte/.Agendador/agendamentosa.conf > /home/marxfcmonte/.Agendador/temp.conf
				mv /home/marxfcmonte/.Agendador/temp.conf /home/marxfcmonte/.Agendador/agendamentosa.conf
				k=$[ k + 1 ]
			done
		else
			dialog --nocancel --title "SEM AGENDAMENTOS ANUAIS" --msgbox "Sem Compromissos agendados." 5 31
		fi
		clear
		opcao1=$(dialog --title "MENU" --menu "Qual opção vai escolher?" 10 41 3 "1" "Menu de remoção de agendamentos" "2" "Menu principal" "3" "Sair" --stdout)
		clear
		case $opcao1 in
			1)
			remover_principal
			;;
			2)
			menu_principal
			;;
			3)
			sair
		esac
		;;
		4)
		menu_principal
		;;
		5)
		sair
		;;
		*)
		cancelar
		;;
	esac
}

listar_principal(){
	num=$(cat /home/marxfcmonte/.Agendador/agendamentosd.conf | tail -n 1 | cut -d " " -f1)
	if ! [ "$num" ]; then
		num=0
	fi
	num1=$(cat /home/marxfcmonte/.Agendador/agendamentosm.conf | tail -n 1 | cut -d " " -f1)
	if ! [ "$num1" ]; then
		num1=0
	fi
	num2=$(cat /home/marxfcmonte/.Agendador/agendamentosa.conf | tail -n 1 | cut -d " " -f1)
	if ! [ "$num2" ]; then
		num2=0
	fi
	opcao1=$(dialog --title "MENU - LISTA DE AGENDAMENTOS" --menu "Qual tipo de agendamento que deseja ver?" 13 48 5 "1" "Listar agendamentos semanais" "2" "Listar agendamentos mensais" "3" "Listar agendamentos anuais" "4" "Menu principal" "5" "Sair" --stdout)
	case $opcao1 in
		1)
		if [ "$num" != "0" ]; then 
			dialog --title "LISTA DE AGENDAMENTOS SAMANAIS" --msgbox "$(cat /home/marxfcmonte/.Agendador/agendamentosd.conf)" 0 0 
		else
			dialog --nocancel --title "SEM AGENDAMENTOS SAMANAIS" --msgbox "Sem Compromissos agendados." 5 31
		fi
		clear
		opcao1=$(dialog --title "MENU" --menu "Qual opção vai escolher?" 10 37 3 "1" "Menu de listar agendamentos" "2" "Menu principal" "3" "Sair" --stdout)
		clear
		case $opcao1 in
			1)
			listar_principal
			;;
			2)
			menu_principal
			;;
			3)
			sair
			;;
			*)
			cancelar
			;;
		esac
		;;
		2)
		if [ "$num1" != "0" ]; then 
			dialog --nocancel --no-collapse --title "LISTA DE AGENDAMENTOS MENSAIS" --msgbox "$(cat agendamentosm.conf)" 0 0 
		else
			dialog --nocancel --title "SEM AGENDAMENTOS MENSAIS" --msgbox "Sem Compromissos agendados." 5 31
		fi
		clear
		opcao1=$(dialog --title "MENU" --menu "Qual opção vai escolher?" 10 37 3 "1" "Menu de listar agendamentos" "2" "Menu principal" "3" "Sair" --stdout)
		clear
		case $opcao1 in
			1)
			listar_principal
			;;
			2)
			menu_principal
			;;
			3)
			sair
			;;
			*)
			cancelar
			;;
		esac
		;;
		3)
		if [ "$num2" != "0" ]; then 
			dialog --nocancel --no-collapse --title "LISTA DE AGENDAMENTOS ANUAIS" --msgbox "$(cat /home/marxfcmonte/.Agendador/agendamentosa.conf)" 0 0 
		else
			dialog --nocancel --title "SEM AGENDAMENTOS ANUAIS" --msgbox "Sem Compromissos agendados." 5 31
		fi
		clear
		opcao1=$(dialog --title "MENU" --menu "Qual opção vai escolher?" 10 37 3 "1" "Menu de listar agendamentos" "2" "Menu principal" "3" "Sair" --stdout)
		clear
		case $opcao1 in
			1)
			listar_principal
			;;
			2)
			menu_principal
			;;
			3)
			sair
			;;
			*)
			cancelar
			;;
		esac
		;;
		4)
		menu_principal
		;;
		5)
		sair
		;;
		*)
		cancelar
		;;
	esac
	}

finalizar_principal(){
	num=$(cat /home/marxfcmonte/.Agendador/finalizar.conf)
	if [ "$num" = "0" ]; then
		echo "1" > /home/marxfcmonte/.Agendador/finalizar.conf
		dialog --nocancel --title "MENSAGEM" --pause "O temporizador foi finalizado." 8 35 20
		echo -e "O temporizador está \033[31mParado\033[0m." > /home/marxfcmonte/.Agendador/status.conf
	else
		dialog --nocancel --title "MENSAGEM" --pause "O temporizador está finalizado." 8 39 20
		clear
	fi
	menu_principal
	}
	
inicializar_principal(){
	num=$(cat /home/marxfcmonte/.Agendador/finalizar.conf)
	if [ "$num" = "1" ]; then
		dialog --nocancel --title "MENSAGEM" --pause "O temporizador foi inicializado." 8 37 20
		bash -c "/usr/share/Agendador/temporalizador.sh" &
		echo -e "O temporizador \033[32mIniciado\033[0m." > /home/marxfcmonte/.Agendador/status.conf
		clear
	else
		dialog --nocancel --title "MENSAGEM" --pause "O temporizador está inicializado." 8 41 20
		clear
	fi
	menu_principal
	}

sair(){
	clear
	dialog --title "SAINDO" --infobox "Saindo do agendador." 3 24
	sleep 1
	clear
	exit 0
}

cancelar(){
	clear
	dialog --title "SAINDO" --infobox "Cancelado pelo usuário." 3 27
	sleep 1
	clear
	exit 0
}

menu_principal(){
	texto="SETAS PARA ESCOLHER E ENTER PARA CONFIRMAR"
	cont="$[${#texto} + 4]"
	opcao=$(dialog --title "MENU - PRINCIPAL" --menu "$texto" 13 $cont 6 "1" "AGENDAR" "2" "REMOVER AGENDAMENTOS" "3" "LISTAR AGENDAMENTOS" "4" "INICIALIZAR O TEMPORIZADOR" "5" "FINALIZAR O TEMPORIZADOR" "6" "SAIR" --stdout)
	clear
	case $opcao in 
		1)
		agendamento_principal
		;;
		2)
		remover_principal
		;;
		3)
		listar_principal
		;;
		4)
		inicializar_principal
		;;
		5)
		finalizar_principal
		;;
		6)
		sair
		;;
		*)
		cancelar
		;;
	esac
}

if ! [ -e /home/marxfcmonte/.Agendador/agendamentosd.conf ]; then
	touch /home/marxfcmonte/.Agendador/agendamentosd.conf
fi
if ! [ -e /home/marxfcmonte/.Agendador/agendamentosm.conf ]; then
	touch /home/marxfcmonte/.Agendador/agendamentosm.conf
fi
if ! [ -e /home/marxfcmonte/.Agendador/agendamentosa.conf ]; then
	touch /home/marxfcmonte/.Agendador/agendamentosa.conf
fi

menu_principal

exit 0

